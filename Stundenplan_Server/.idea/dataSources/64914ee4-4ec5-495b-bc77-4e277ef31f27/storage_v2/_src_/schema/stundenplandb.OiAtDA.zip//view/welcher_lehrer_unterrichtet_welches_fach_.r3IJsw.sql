create definer = justus@`%` view `welcher lehrer unterrichtet welches fach?` as
select `stundenplandb`.`lehrer`.`Nachname` AS `Nachname`, `stundenplandb`.`faecher`.`Fach` AS `Fach`
from (`stundenplandb`.`faecher`
         join (`stundenplandb`.`lehrer` join `stundenplandb`.`fach-lehrer` on (`stundenplandb`.`lehrer`.`Lehrer-ID` =
                                                                               `stundenplandb`.`fach-lehrer`.`Lehrer-ID`))
              on (`stundenplandb`.`faecher`.`Fach-ID` = `stundenplandb`.`fach-lehrer`.`Fach-ID`))
order by `stundenplandb`.`lehrer`.`Nachname`, `stundenplandb`.`faecher`.`Fach`;

