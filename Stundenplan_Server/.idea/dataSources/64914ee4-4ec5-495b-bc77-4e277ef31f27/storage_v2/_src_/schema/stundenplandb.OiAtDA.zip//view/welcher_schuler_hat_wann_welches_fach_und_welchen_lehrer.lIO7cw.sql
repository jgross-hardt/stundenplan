create definer = justus@`%` view `welcher schüler hat wann welches fach und welchen lehrer` as
select `stundenplandb`.`schueler`.`Nachname` AS `Nachname`,
       `stundenplandb`.`schueler`.`Vorname`  AS `Vorname`,
       `stundenplandb`.`stunden`.`Tag`       AS `Tag`,
       `stundenplandb`.`stunden`.`Stunde`    AS `Stunde`,
       `stundenplandb`.`faecher`.`Fach`      AS `Fach`,
       `stundenplandb`.`lehrer`.`Nachname`   AS `Lehrer`
from (`stundenplandb`.`lehrer`
         join ((`stundenplandb`.`faecher` join `stundenplandb`.`fach-lehrer` on (`stundenplandb`.`faecher`.`Fach-ID` =
                                                                                 `stundenplandb`.`fach-lehrer`.`Fach-ID`)) join (`stundenplandb`.`stunden` join ((`stundenplandb`.`kurse` join (`stundenplandb`.`schueler` join `stundenplandb`.`schueler-kurs` on (
        `stundenplandb`.`schueler`.`Schueler-ID` = `stundenplandb`.`schueler-kurs`.`Schueler-ID`)) on (
        `stundenplandb`.`kurse`.`Kurs-ID` =
        `stundenplandb`.`schueler-kurs`.`Kurs-ID`)) join `stundenplandb`.`kurs-stunde` on (
        `stundenplandb`.`kurse`.`Kurs-ID` = `stundenplandb`.`kurs-stunde`.`Kurs-ID`)) on (
        `stundenplandb`.`stunden`.`Stunden-ID` = `stundenplandb`.`kurs-stunde`.`Stunden-ID`)) on (
        `stundenplandb`.`faecher`.`Fach-ID` = `stundenplandb`.`kurse`.`Fach-ID`))
              on (`stundenplandb`.`lehrer`.`Lehrer-ID` = `stundenplandb`.`kurse`.`Lehrer-ID` and
                  `stundenplandb`.`lehrer`.`Lehrer-ID` = `stundenplandb`.`fach-lehrer`.`Lehrer-ID`))
order by `stundenplandb`.`schueler`.`Nachname`, `stundenplandb`.`schueler`.`Vorname`, `stundenplandb`.`stunden`.`Tag`,
         `stundenplandb`.`stunden`.`Stunde`;

