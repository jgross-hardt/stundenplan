create view `welcher lehrer unterrichtet welches fach?` as
select `stundenplan`.`lehrer`.`Nachname` AS `Nachname`, `stundenplan`.`faecher`.`Fach` AS `Fach`
from (`stundenplan`.`faecher`
         join (`stundenplan`.`lehrer` join `stundenplan`.`fach-lehrer` on (`stundenplan`.`lehrer`.`Lehrer-ID` =
                                                                           `stundenplan`.`fach-lehrer`.`Lehrer-ID`))
              on (`stundenplan`.`faecher`.`Fach-ID` = `stundenplan`.`fach-lehrer`.`Fach-ID`))
order by `stundenplan`.`lehrer`.`Nachname`, `stundenplan`.`faecher`.`Fach`;

