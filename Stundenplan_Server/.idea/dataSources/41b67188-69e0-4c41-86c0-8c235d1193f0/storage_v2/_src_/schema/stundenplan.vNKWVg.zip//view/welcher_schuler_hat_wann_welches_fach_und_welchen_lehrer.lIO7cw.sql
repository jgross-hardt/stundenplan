create view `welcher schüler hat wann welches fach und welchen lehrer` as
select `stundenplan`.`schueler`.`Nachname` AS `Nachname`,
       `stundenplan`.`schueler`.`Vorname`  AS `Vorname`,
       `stundenplan`.`stunden`.`Tag`       AS `Tag`,
       `stundenplan`.`stunden`.`Stunde`    AS `Stunde`,
       `stundenplan`.`faecher`.`Fach`      AS `Fach`,
       `stundenplan`.`lehrer`.`Nachname`   AS `Lehrer`
from (`stundenplan`.`lehrer`
         join ((`stundenplan`.`faecher` join `stundenplan`.`fach-lehrer` on (`stundenplan`.`faecher`.`Fach-ID` =
                                                                             `stundenplan`.`fach-lehrer`.`Fach-ID`)) join (`stundenplan`.`stunden` join ((`stundenplan`.`kurse` join (`stundenplan`.`schueler` join `stundenplan`.`schueler-kurs` on (
        `stundenplan`.`schueler`.`Schueler-ID` = `stundenplan`.`schueler-kurs`.`Schueler-ID`)) on (
        `stundenplan`.`kurse`.`Kurs-ID` =
        `stundenplan`.`schueler-kurs`.`Kurs-ID`)) join `stundenplan`.`kurs-stunde` on (`stundenplan`.`kurse`.`Kurs-ID` =
                                                                                       `stundenplan`.`kurs-stunde`.`Kurs-ID`)) on (
        `stundenplan`.`stunden`.`Stunden-ID` =
        `stundenplan`.`kurs-stunde`.`Stunden-ID`)) on (`stundenplan`.`faecher`.`Fach-ID` = `stundenplan`.`kurse`.`Fach-ID`))
              on (`stundenplan`.`lehrer`.`Lehrer-ID` = `stundenplan`.`kurse`.`Lehrer-ID` and
                  `stundenplan`.`lehrer`.`Lehrer-ID` = `stundenplan`.`fach-lehrer`.`Lehrer-ID`))
order by `stundenplan`.`schueler`.`Nachname`, `stundenplan`.`schueler`.`Vorname`, `stundenplan`.`stunden`.`Tag`,
         `stundenplan`.`stunden`.`Stunde`;

